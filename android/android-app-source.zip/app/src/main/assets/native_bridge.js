(function(){
  'use strict';
  if (window.__BLINK_ANDROID_BLE_POLYFILL__) return;
  window.__BLINK_ANDROID_BLE_POLYFILL__ = true;

  const SERVICE = 'afaf0001-7c35-4a6d-9f0e-2ea3117f1000';
  const LIVE    = 'afaf0002-7c35-4a6d-9f0e-2ea3117f1000';
  const COMMAND = 'afaf0003-7c35-4a6d-9f0e-2ea3117f1000';
  const MAP     = 'afaf0004-7c35-4a6d-9f0e-2ea3117f1000';
  const STATUS  = 'afaf0005-7c35-4a6d-9f0e-2ea3117f1000';

  function bytesToBase64(data) {
    let u8;
    if (data instanceof Uint8Array) u8 = data;
    else if (ArrayBuffer.isView(data)) u8 = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    else if (data instanceof ArrayBuffer) u8 = new Uint8Array(data);
    else u8 = new Uint8Array(data || []);
    let s = '';
    const step = 0x4000;
    for (let i=0;i<u8.length;i+=step) {
      const chunk=u8.subarray(i,Math.min(i+step,u8.length));
      s += String.fromCharCode.apply(null, Array.from(chunk));
    }
    return btoa(s);
  }

  function base64ToBytes(b64) {
    const s=atob(b64||'');
    const u8=new Uint8Array(s.length);
    for(let i=0;i<s.length;i++)u8[i]=s.charCodeAt(i)&255;
    return u8;
  }

  const chars = new Map();
  function makeCharacteristic(uuid) {
    uuid=String(uuid).toLowerCase();
    if(chars.has(uuid))return chars.get(uuid);
    const listeners=[];
    const ch={
      uuid,
      startNotifications(){ return Promise.resolve(ch); },
      stopNotifications(){ return Promise.resolve(ch); },
      addEventListener(type,fn){ if(type==='characteristicvaluechanged' && typeof fn==='function')listeners.push(fn); },
      removeEventListener(type,fn){ const i=listeners.indexOf(fn); if(i>=0)listeners.splice(i,1); },
      writeValueWithoutResponse(data){ AndroidBLE.writeValue(uuid,bytesToBase64(data)); return Promise.resolve(); },
      writeValue(data){ AndroidBLE.writeValue(uuid,bytesToBase64(data)); return Promise.resolve(); },
      __emit(bytes){
        const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
        listeners.slice().forEach(fn=>{try{fn({target:{value:dv}})}catch(e){console.error(e)}});
      }
    };
    chars.set(uuid,ch);return ch;
  }

  const service={
    uuid:SERVICE,
    getCharacteristic(uuid){ return Promise.resolve(makeCharacteristic(uuid)); }
  };
  const server={
    connected:true,
    getPrimaryService(uuid){
      if(String(uuid).toLowerCase()!==SERVICE) return Promise.reject(new Error('BLE service không đúng.'));
      return Promise.resolve(service);
    }
  };

  const deviceListeners={disconnected:[]};
  const device={
    name:'BLINK-REDLEO',
    id:'android-native-ble',
    gatt:{
      connected:false,
      connect(){ this.connected=true; server.connected=true; return Promise.resolve(server); },
      disconnect(){ try{AndroidBLE.disconnect();}catch(e){} }
    },
    addEventListener(type,fn){ if(type==='gattserverdisconnected' && typeof fn==='function')deviceListeners.disconnected.push(fn); },
    removeEventListener(type,fn){ if(type==='gattserverdisconnected'){const i=deviceListeners.disconnected.indexOf(fn);if(i>=0)deviceListeners.disconnected.splice(i,1);} }
  };

  let pendingResolve=null,pendingReject=null;
  const bluetoothApi={
    requestDevice(){
      return new Promise((resolve,reject)=>{
        pendingResolve=resolve;pendingReject=reject;
        try{AndroidBLE.connect();}catch(e){pendingResolve=null;pendingReject=null;reject(e);}
      });
    },
    getAvailability(){ return Promise.resolve(true); },
    getDevices(){ return Promise.resolve(device.gatt.connected?[device]:[]); },
    setScreenDimEnabled(enabled){ try{AndroidBLE.setKeepScreenOn(!enabled);}catch(e){} return Promise.resolve(); }
  };

  try{
    Object.defineProperty(navigator,'bluetooth',{configurable:true,enumerable:true,value:bluetoothApi});
  }catch(e){
    try{navigator.bluetooth=bluetoothApi}catch(_e){}
  }

  window.__androidBleConnected=function(name){
    device.name=name||'BLINK-REDLEO';device.gatt.connected=true;server.connected=true;
    if(pendingResolve){const r=pendingResolve;pendingResolve=pendingReject=null;r(device);}
  };
  window.__androidBleConnectError=function(message){
    const err=new Error(message||'Không kết nối được ESP32-S3.');
    if(pendingReject){const r=pendingReject;pendingResolve=pendingReject=null;r(err);}
  };
  window.__androidBleDisconnected=function(){
    device.gatt.connected=false;server.connected=false;
    deviceListeners.disconnected.slice().forEach(fn=>{try{fn({target:device})}catch(e){}});
  };
  window.__androidBlePacket=function(uuid,b64){
    try{makeCharacteristic(String(uuid).toLowerCase()).__emit(base64ToBytes(b64));}catch(e){console.error('BLE packet',e);}
  };

  // The web button still runs its own fullscreen/orientation logic. Native Android
  // additionally locks the Activity when this button is touched.
  document.addEventListener('click',function(ev){
    const t=ev.target&&ev.target.closest?ev.target.closest('#rotateLandscapeBtn'):null;
    if(t){try{AndroidBLE.setOrientation('landscape')}catch(e){}}
  },true);

  window.addEventListener('orientationchange',function(){
    try{AndroidBLE.setKeepScreenOn(true)}catch(e){}
  });

  console.log('BLINK REDLEO Android native BLE polyfill installed');
})();
